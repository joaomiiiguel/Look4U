self.__precacheManifest = [
  {
    "revision": "73cbb4826ea9e888dd74",
    "url": "/static/js/app.1f07d483.chunk.js"
  },
  {
    "revision": "1607ec186986866fe84a",
    "url": "/static/js/runtime~app.10373daf.js"
  },
  {
    "revision": "c228f651fc218008d1df",
    "url": "/static/js/2.539acc39.chunk.js"
  },
  {
    "revision": "13e78a8c12d37502768e1c08d5eeeb31",
    "url": "/static/media/polo.c455d515.png"
  },
  {
    "revision": "72a3a9a606e300a3756d65d06845c743",
    "url": "/static/media/camisa.ee5d5f81.png"
  },
  {
    "revision": "b6de664dee39d9c6a6517366e0c1b1bf",
    "url": "/static/media/calca.deb2333c.png"
  },
  {
    "revision": "88878e708f21b3314f9c84e82929d83f",
    "url": "/static/media/short.958d0477.png"
  },
  {
    "revision": "1a6e7758d28b79f4c742955fe5ca4bf3",
    "url": "/./fonts/MazzardH-Bold.otf"
  },
  {
    "revision": "c0cb8521541454f1de42ca46170b0bac",
    "url": "/look4u/static/media/corpoNu.d98b2710.png"
  },
  {
    "revision": "6d999266ca01868f6fbfb1acc62ce6b6",
    "url": "/look4u/static/media/bolinha.6989fef1.png"
  },
  {
    "revision": "b06871f281fee6b241d60582ae9369b9",
    "url": "/look4u/./fonts/FontAwesome.ttf"
  },
  {
    "revision": "22ac079e4f00dc25683b8856ca201867",
    "url": "/look4u/static/media/camisa06.5bf3b834.png"
  },
  {
    "revision": "4ad6227eb3057b58af5cae6921929050",
    "url": "/look4u/static/media/camisa07.ff227f87.png"
  },
  {
    "revision": "7b0a2c1e223b28f70be65c767a07133d",
    "url": "/look4u/static/media/camisa01.e9570f37.png"
  },
  {
    "revision": "22c08f93bdfdb47f86ba05b2a56e76f6",
    "url": "/look4u/static/media/camisa02.9e7b5e4b.png"
  },
  {
    "revision": "31028c167181ee83aa80a7204a321770",
    "url": "/look4u/static/media/camisa04.a0c7d42e.png"
  },
  {
    "revision": "a65d9d9e22c8da4d2e9460eaa76a1782",
    "url": "/look4u/static/media/camisa05.7270b0cc.png"
  },
  {
    "revision": "521777bb62853078a7e370a88a5c944c",
    "url": "/look4u/static/media/short01.21c79a8a.png"
  },
  {
    "revision": "d4dd15b10145cea6152f8e9a2a6d7e63",
    "url": "/look4u/static/media/short02.91a695f8.png"
  },
  {
    "revision": "b190535925e5cb8ae06e587c075ac87d",
    "url": "/look4u/static/media/calca01.d70a39a6.png"
  },
  {
    "revision": "fc5730dce0381cdeeaaec56f5a53e90a",
    "url": "/look4u/static/media/calca02.7da99f5a.png"
  },
  {
    "revision": "24b730fe922dd08f9b27ee28f1256f88",
    "url": "/look4u/static/media/logoLacoste.bb52b285.png"
  },
  {
    "revision": "18d09e1978c9c8c0236825083e01d0da",
    "url": "/look4u/static/media/flamengoLogo.521e8caa.png"
  },
  {
    "revision": "d47ca68bd257682a7864a94c8e8fda03",
    "url": "/look4u/static/media/corinthiasLogo.efbac679.png"
  },
  {
    "revision": "d4eb0ec7b07fd166b933e2d35c8a440a",
    "url": "/look4u/./fonts/MazzardH-Black.otf"
  },
  {
    "revision": "927a341e1b97948238ecc436d3fd17ad",
    "url": "/look4u/static/media/logoBranca.7c6c8ce9.png"
  },
  {
    "revision": "ffa6bee0457999fcb6dea4cb4993bb29",
    "url": "/look4u/static/media/logoOriginal.dd83b8fc.png"
  },
  {
    "revision": "26bb3e073884f6b2549bd01d84dffb02",
    "url": "/look4u/static/media/carrinhoDeCompras.fff574f2.png"
  },
  {
    "revision": "3a2ba31570920eeb9b1d217cabe58315",
    "url": "/look4u/./fonts/AntDesign.ttf"
  },
  {
    "revision": "744ce60078c17d86006dd0edabcd59a7",
    "url": "/look4u/./fonts/Entypo.ttf"
  },
  {
    "revision": "ca9ce9ff0676a9b04ef0f8a3ad17dd08",
    "url": "/look4u/./fonts/Feather.ttf"
  },
  {
    "revision": "c39278f7abfc798a241551194f55e29f",
    "url": "/look4u/./fonts/FontAwesome5_Brands.ttf"
  },
  {
    "revision": "b70cea0339374107969eb53e5b1f603f",
    "url": "/look4u/./fonts/FontAwesome5_Solid.ttf"
  },
  {
    "revision": "b49ae8ab2dbccb02c4d11caaacf09eab",
    "url": "/look4u/./fonts/Fontisto.ttf"
  },
  {
    "revision": "e20945d7c929279ef7a6f1db184a4470",
    "url": "/look4u/./fonts/Foundation.ttf"
  },
  {
    "revision": "b2e0fc821c6886fb3940f85a3320003e",
    "url": "/look4u/./fonts/Ionicons.ttf"
  },
  {
    "revision": "3c851d60ad5ef3f2fe43ebd263490d78",
    "url": "/look4u/./fonts/MaterialCommunityIcons.ttf"
  },
  {
    "revision": "a37b0c01c0baf1888ca812cc0508f6e2",
    "url": "/look4u/./fonts/MaterialIcons.ttf"
  },
  {
    "revision": "d2285965fe34b05465047401b8595dd0",
    "url": "/look4u/./fonts/SimpleLineIcons.ttf"
  },
  {
    "revision": "d8e8c7bd582d0a9005d9559094f6b773",
    "url": "/look4u/index.html"
  },
  {
    "revision": "ec543248d7b23864564429fc03837190",
    "url": "/look4u/serve.json"
  },
  {
    "revision": "2002987acac9deb6803ab4ba381226ba",
    "url": "/look4u/expo-service-worker.js"
  },
  {
    "revision": "b93eb0452dfb12cc7c9cb9ebba3a6dbb",
    "url": "/look4u/register-service-worker.js"
  },
  {
    "revision": "8dfb31a517ad9dfd8625dfeabad8466c",
    "url": "/look4u/static/js/2.539acc39.chunk.js.LICENSE.txt"
  },
  {
    "revision": "afd5733ac789ab1795f1ed7a26e1ecd3",
    "url": "/look4u/favicon-16.png"
  },
  {
    "revision": "3d85359b37ca7590f8e91d593d02ddaf",
    "url": "/look4u/favicon-32.png"
  },
  {
    "revision": "fab03a91f30543347e9ce9ed9d4c87b1",
    "url": "/look4u/favicon.ico"
  },
  {
    "revision": "faa2ecc032ece74e478c505e9bccbb7b",
    "url": "/look4u/manifest.json"
  }
];